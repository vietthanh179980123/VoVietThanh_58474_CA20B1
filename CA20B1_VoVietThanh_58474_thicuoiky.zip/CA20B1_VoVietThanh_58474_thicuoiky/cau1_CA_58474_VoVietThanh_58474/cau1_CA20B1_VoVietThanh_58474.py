"""
    Họ và tên: Võ Viết Thanh
    Lớp: CA20B1
    MSV: 58474
    Đề: 02
"""
def hienthi_songuyento():
    def songuyento(n):
        # Check số nguyên tố
        t = True
        for j in range(2,n):
            if n%j==0:
                f = False
                break
        return t

    def in_songuyento(a=30, b=200):
        print("Các số nguyên nguyên tố trong khoảng từ", a, "đến", b, "là:")
        for i in range(a,b + 1):
            if songuyento(i):
                print(i, end=" ")
        print()
    in_songuyento(30,200)

if __name__=="__main__":
    hienthi_songuyento()





""" Nhập số nhị phân chuyển qua số thập phân
a = input('Nhập số nhị phân vào đây : ')
ar = [int(i) for  i in a]
ar  = ar[::-1]
res = []
for i in range(len(ar)):
    res.append(ar[i]*(2**i))
sum_res = sum(res)
print('Số nhị phân ',a, 'chuyển đổi qua dạng thập phân là : ',sum_res)"""
