"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Turtle graphics windows do not automatically expand in size. What do you suppose
happens when a Turtle object attempts to move beyond a window boundary?
Solution:
    - It's will error and required the programmer fix the width and height
    ....
"""