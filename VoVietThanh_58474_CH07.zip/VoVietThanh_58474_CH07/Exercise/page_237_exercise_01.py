"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Explain the advantages and disadvantages of lossless and lossy image filecompression scheme
Solution:
    - Advantages:
    + The image is displayed, the original color values are restored during the
    process of decompression (Lossless compression)
    +  To save even more bits, another scheme analyzes larger regions of pixels
    and saves a color value that the pixels’ colors approximate (Lossy scheme)
    - Disadvantages:
    + Some of the original color information is lost
    + When the image is decompressed and displayed, the human eye usually is not able to detect the difference
    between the new colors and the original ones
    ....
"""