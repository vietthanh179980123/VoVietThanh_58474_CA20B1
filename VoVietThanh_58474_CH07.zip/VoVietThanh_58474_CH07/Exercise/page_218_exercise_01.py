"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Explain the importance of the interface of a class of objects
Solution: The importance is: the information in an interface usually includes the
method headers and documentation about arguments, return values, and changes of state.
    ....
"""