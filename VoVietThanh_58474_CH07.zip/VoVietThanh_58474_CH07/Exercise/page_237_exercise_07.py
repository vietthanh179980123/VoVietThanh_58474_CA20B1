"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Why does the blur function need to work with a copy of the original image?
Solution:
   The function blur expects an image as an argument and
    returns a copy of that image with blurring. The function blur begins its traversal of the grid
    with position (1, 1) and ends with position (width 2 2, height 2 2). This means that the algorithm does not transform the pixels on the image’s outer edges
    ....
"""