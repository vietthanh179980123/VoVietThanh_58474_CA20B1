"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: What is object instantiation? What are the options at the programmer’s disposal
during this process?
Solution:
    - Before you use some objects, like a Turtle object, you must create them. To be precise,
    you must create an instance of the object’s class. The process of creating an object is called
    instantiation
    - The programmer must explicitly instantiate other classes of objects, including those that have no literals
    ....
"""