"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Describe how a row-major traversal visits every position in a two-dimensional grid
Solution:
   - A nested loop structure is used to visit each position in a two-dimensional grid. In a
    row-major traversal, the outer loop of this structure moves down the rows using the
    y-coordinate, and the inner loop moves across the columns using the x-coordinate. Each
    column in a row is visited before moving to the next row. A column-major traversal
    reverses these settings.
    ....
"""
width = 2
height = 3
for y in range(height):
    for x in range(width):
        print((x, y), end = " ")