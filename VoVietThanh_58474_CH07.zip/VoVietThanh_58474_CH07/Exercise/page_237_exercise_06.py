"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Explain why one would use the clone method with a given object
Solution:
   - Because the method clone builds and returns a new image with the
    same attributes as the original one, but with an empty string as the filename
    ....
"""