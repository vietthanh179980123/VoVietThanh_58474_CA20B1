"""
Author: Vo Viet Thanh
Date: 16/10/2021
Program: Describe the difference between Cartesian coordinates and screen coordinates.
Solution:
   - The coordinate system for Turtle graphics is the standard Cartesian system,
    with the origin (0, 0) at the center of a window
    ....
"""