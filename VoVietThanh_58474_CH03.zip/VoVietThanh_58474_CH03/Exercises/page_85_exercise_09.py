"""
Author: Võ Viết Thanh
Date: 17/09/2021
Program: Does the Boolean expression count > 0 and total // count > 0 contain a
potential error? If not, why not?
Solution: Yes, it contain a potential error
  ....
"""
