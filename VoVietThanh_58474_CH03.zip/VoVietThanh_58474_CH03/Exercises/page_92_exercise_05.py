"""
Author: Võ Viết Thanh
Date: 17/09/2021
Program: What is the maximum number of guesses necessary to guess correctly a given number between the numbers N and M?
well suited.
Solution: Unlimited
  ....
"""
