"""
Author: Võ Viết Thanh
Date: 16/09/2021
Program: Explain the role of the trailing else part of an extended if statement.
Solution: When the condition in if statement is true, it will excute the command and when it false, the conditon in else will excute

  ....
"""
