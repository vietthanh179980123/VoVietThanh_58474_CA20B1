"""
Author: Võ Viết Thanh
Date: 16/09/2021
Program: Write a loop that counts the number of space characters in a string. Recall that the
space character is represented as ' '.
Solution:

  ....
"""
data = 'Viet Thanh'
number_of_characters = len(data)
print('Number of characters in data :', number_of_characters)
