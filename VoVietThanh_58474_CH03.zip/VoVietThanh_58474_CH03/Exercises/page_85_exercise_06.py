"""
Author: Võ Viết Thanh
Date: 16/09/2021
Program: Construct truth tables for the following Boolean expressions:
a. not (A or B)
b. not A and not B
Solution:
    A = True
    B = False
    a. Not A or B
    The output is True
    b. Not A and not B
    The output is False
  ....
"""
