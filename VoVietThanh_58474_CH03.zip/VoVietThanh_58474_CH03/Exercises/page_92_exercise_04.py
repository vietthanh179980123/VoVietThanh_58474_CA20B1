"""
Author: Võ Viết Thanh
Date: 17/09/2021
Program: Describe the purpose of the break statement and the type of problem for which it is
well suited.
Solution:
    - Purpose: The break statement will cause an exit from the loop
    - Type of problem: The user wants to quit, the input will equal the empty string
  ....
"""
