"""
Author: Võ Viết Thanh
Date: 15/09/2021
Program: Explain the role of the variable in the header of a for loop.
Solution:
    The variable in the header of a for loop is declare the input in the loop
  ....
"""
