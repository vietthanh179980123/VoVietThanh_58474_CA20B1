"""
Author: Võ Viết Thanh
Date: 16/09/2021
Program: Assume that x refers to a number. Write a code segment that prints the number’s
absolute value without using Python’s abs function.
Solution:

  ....
"""
x = int(input("Nhap so vao day: "))
if x>0:
    print("x= ", x)
else:
    print("x= ", x*-1)

