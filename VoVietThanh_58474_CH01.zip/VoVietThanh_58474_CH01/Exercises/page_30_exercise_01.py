"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Suppose your script attempts to print the value of a variable that has not yet been
assigned a value. How does the Python interpreter react?
Solution:
     SyntaxError: unexpected indent
    ....
"""
