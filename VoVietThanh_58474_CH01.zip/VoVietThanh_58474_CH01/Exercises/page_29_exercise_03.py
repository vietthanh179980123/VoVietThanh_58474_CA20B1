"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Answer the question, What is a Python script
Solution:
     Python scripts are programs that are saved in files and run from a terminal command
    prompt. An interactive script consists of a set of input statements, statements that process these inputs, and statements that output the results.
    ....
"""
