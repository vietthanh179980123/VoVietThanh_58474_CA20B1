"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Write an algorithm that describes a common task, such as baking a cake or operating a DVD player.
Solution:
    1. Put the button to open the door of the oven
    2. Put the cake into an oven
    3. Close the door and turn the knob to choose suitable time and temperature
    4. Wait a cake until it done
    ....
"""
