"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Why does Python code generate fewer types of syntax errors than code in other
programming languages?
Solution:
    the Python language is much simpler than other programming languages. Consequently, there are fewer types of syntax errors to encounter and correct, and
    a lot less syntax for you to learn
    ....
"""

