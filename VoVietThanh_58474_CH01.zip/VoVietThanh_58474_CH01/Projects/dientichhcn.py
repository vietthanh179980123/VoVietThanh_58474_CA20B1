chieudai = float(input("Nhap chieu dai cua hinh chu nhat: "))
chieurong = float(input("Nhap chieu rong cua hinh chu nhat: "))
dientich = chieudai*chieurong
print("Dien tich cua hihh chu nhat la: ", dientich)
