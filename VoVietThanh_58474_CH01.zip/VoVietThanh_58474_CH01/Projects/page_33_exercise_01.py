"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Open a Python shell, enter the following expressions, and observe the results:
Solution:
    a. 8
    It will display 8
    b. 8*2
    It will display 8*2
    c. 8**2
    It will display 8/2
    d. 8/12
    It will display 8/12
    e. 8//12
    It will display 8//12
    f. 8/0
    It will display 8/0
    ....
"""

