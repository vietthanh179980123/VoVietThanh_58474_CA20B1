"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: . Write and test a program that accepts the user’s name (as text) and age (as a number)
as input. The program should output a sentence containing the user’s name and age
Solution:
    ....
"""
name=input("Nhap ten cua ban: ")
age=input("Nhap tuoi cua ban: ")
print("Ten cua ban la: ",name)
print("Tuoi cua ban la: ",age)
