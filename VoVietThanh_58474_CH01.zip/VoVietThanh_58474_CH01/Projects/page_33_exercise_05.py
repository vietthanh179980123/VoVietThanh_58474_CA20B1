"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Modify the program of Project 4 to compute the area of a triangle. Issue the
appropriate prompts for the triangle’s base and height, and change the names of
the variables appropriately. Then, use the formula .5 * base * height to compute the area. Test the program from an IDLE window
Solution:
    ....
"""
base = float(input("Nhap day cua tam giac: "))
height = float(input("Nhap chieu cao cua tam giac: "))
area = 5*base*height
print("Dien tich cua tam giac la: ", area)

