"""
Author: Võ Viết Thanh
Date: 29/08/2021
Program: Enter an input statement using the input function at the shell prompt. When the prompt asks you for input, enter your first name, observe the results, and explain
what happened
Solution:
   It will display your first name you enter before
    ....
"""

