"""
Author: Võ Viết Thanh
Date: 29/08/2021
Program: Enter an input statement using the input function at the shell prompt. When the
prompt asks you for input, enter a number. Then, attempt to add 1 to that number, observe the results, and explain what happened
Solution:
    When attemp 1 to that number, the result we enter before doesn't change
    ....
"""

