base = float(input("Nhap day cua tam giac: "))
height = float(input("Nhap chieu cao cua tam giac: "))
area = 5*base*height
print("Dien tich cua tam giac la: ", area)
