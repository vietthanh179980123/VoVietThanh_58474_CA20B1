"""
Author: Võ Viết Thanh
Date: 28/08/2021
Program: Write a Python program that prints (displays) your name, address, and telephone number
Solution:
    ....
"""
name = input("Nhap ten cua ban: ")
address = input("Nhap dia chi cua ban: ")
telephonenumber = input("Nhap so dien thoai ca nhan: ")
print("Ten cua ban la: ",name)
print("Dia chi cua ban la: ",address)
print("So dien thoai cua ban la: ",telephonenumber)
