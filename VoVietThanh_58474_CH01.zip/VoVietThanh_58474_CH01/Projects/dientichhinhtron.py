radius=float(input("Nhap ban kinh duong tron: "))
area=3.14*radius**2
print("Dien tich hinh tron la: ",area)
