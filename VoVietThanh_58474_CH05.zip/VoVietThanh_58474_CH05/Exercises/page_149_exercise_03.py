"""
Author: Vo Viet Thanh
Date: 8/10/2021
Program: Use the function even to simplify the definition of the function odd presented in
this section.
Solution:

    ....
"""
def even(x):
    if x % 2 == 0:
        print("Even")
    else:
        print("Odd")
