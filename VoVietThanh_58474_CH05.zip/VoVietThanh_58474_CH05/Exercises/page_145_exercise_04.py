"""
Author: Vo Viet Thanh
Date: 8/10/2021
Program: Write a loop that accumulates the sum of the numbers in a list named data.
Solution:
    ....
"""
Sum = 0
for x in [1,2,3,4,5,7,8,9,11]:
    Sum = Sum + x
print(Sum)
