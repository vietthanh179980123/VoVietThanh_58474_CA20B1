"""
Author: Vo Viet Thanh
Date: 8/10/2021
Program: Define a function named even. This function expects a number as an argument and
returns True if the number is divisible by 2, or it returns False otherwise. (Hint: A
number is evenly divisible by 2 if the remainder is 0.)
Solution:
    ....
"""
def even(x):
    if x % 2 == 0:
        return True
    else:
        return False
