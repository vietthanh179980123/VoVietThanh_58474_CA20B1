"""
Author: Vo Viet Thanh
Date: 8/10/2021
Program: Give three examples of real-world objects that behave like a dictionary
Solution:
    - Users name
    - Age
    - Job
    ....
"""
