"""
Author: Võ Viết Thanh
Date: 03/09/2021
Program: Consult Table 2-5 to write the ASCII values of the characters '$' and '&'
Solution: Following table 2-5 in page 48
    - Value of characters '$' is row 3, columm 6
    - Value of characters '&' is row 3, columm 8
  ....
"""
