"""
Author: Võ Viết Thanh
Date: 03/09/2021
Program: Let x = 4.66 Write the values of the following expressions:
a. round(x)
b. int(x)
Solution:
    a. round(4.66) = 5
    b. int(4.66) = 4

  ....
"""
