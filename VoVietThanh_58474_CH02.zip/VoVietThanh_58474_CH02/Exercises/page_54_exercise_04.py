"""
Author: Võ Viết Thanh
Date: 03/09/2021
Program: How does a Python programmer concatenate a numeric value to a string value?
Solution: A Python programmer use the str function to convert the value of profit to a string and then concatenate this string to the symbol
  ....
"""
