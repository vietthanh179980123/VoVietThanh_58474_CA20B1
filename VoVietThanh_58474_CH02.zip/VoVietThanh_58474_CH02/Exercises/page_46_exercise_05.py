"""
Author: Võ Viết Thanh
Date: 03/09/2021
Program: Which of the following are valid variable names?
    a. length
    b. _width
    c. firstBase
    d. 2MoreToGo
    e. halt!
Solution: The valid variable names are:
    a. length
    c. firstBase
    d. 2MoreToGo
  ....
"""
