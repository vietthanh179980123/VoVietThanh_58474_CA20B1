"""
Author: Võ Viết Thanh
Date: 03/09/2021
Program: Let the variable x be "dog" and the variable y be "cat". Write the values returned
    by the following operations:
    a. x + y
    b. "the " + x + " chases the " + y
    c. x * 4
Solution:
    x = dog
    y= cat
    a. x+y
    ....
"""
x="dog"
y="cat"
print( x+ " + "+ y)
print("the " + x + " chases the " + y)
print(x" *4 ")
