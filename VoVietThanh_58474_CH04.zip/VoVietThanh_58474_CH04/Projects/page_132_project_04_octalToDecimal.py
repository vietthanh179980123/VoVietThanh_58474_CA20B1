"""
Author: Võ Viết Thanh
Date: 25/09/2021
Program: Octal numbers have a base of eight and the digits 0–7. Write the scripts octalToDecimal.py and decimalToOctal.py, which convert numbers between the octal
and decimal representations of integers. These scripts use algorithms that aresimilar to those of the binaryToDecimal and decimalToBinary scripts developed in Section 4-3.
Solution:
  ....
"""
otn=int(input('Enter a string of octal digits: '))
i = 1
dc = 0
while (otn!= 0):
    rmd = otn % 10
    otn //= 10
    dc += rmd * i
    i *= 8
print('The integer value is ',dc)
