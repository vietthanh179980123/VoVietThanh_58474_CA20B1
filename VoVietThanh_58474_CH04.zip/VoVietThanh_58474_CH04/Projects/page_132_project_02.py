"""
Author: Võ Viết Thanh
Date: 25/09/2021
Program: Write a script that inputs a line of encrypted text and a distance value and outputs
plaintext using a Caesar cipher. The script should work for any printable characters
Solution:
  ....
"""
text = input("Please enter any text: ")
d = int(input("Please enter the distance : "))
plainText = ""
for ch in text:
    ordvalue = ord(ch)
    ciphervalue = ordvalue - d
    if ciphervalue < ord('a'):
        ciphervalue = ord('z') - \
        (d - (ord('a')-ordvalue - 1))
        plainText += chr(ciphervalue)
print(plainText)
