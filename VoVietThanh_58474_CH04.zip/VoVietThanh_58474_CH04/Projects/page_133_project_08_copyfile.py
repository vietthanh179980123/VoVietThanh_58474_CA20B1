"""
Author: Võ Viết Thanh
Date: 26/09/2021
Program: Write a script named copyfile.py. This script should prompt the user for the
names of two text files. The contents of the first file should be input and written
to the second file.
Solution:
  ....
"""
# mở 2 file project8_f1.txt và project8_f2.txt
file1=input("Enter the input filename with extension: ")
file2=input("Enter the output filename with extension: ")
f1=open(file1,"r")
f2=open(file2,"w+")
content=f1.read()
f2.write(content)
f1.close()
f2.close()
