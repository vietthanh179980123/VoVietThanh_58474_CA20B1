"""
Author: Võ Viết Thanh
Date: 25/09/2021
Program: Modify the scripts of Projects 1 and 2 to encrypt and decrypt entire files of text.
Solution:
  ....
"""
#project 1
fname= open("D:\Writing_code_Python\Learning_Python_in_book\VoVietThanh_58474_CH04\Projects\modifyproject1_2.txt",'r')
text = fname.read()
word = len(text.split())
text = input("Please enter any text: ")
d = int(input("Please enter the distance : "))
encryptedCode = ""
for character in text:
    oV = ord(character)
    c = oV + d
    if c > ord('z'):
        c = ord('a') + d - (ord('z') - oV + 1)
        encryptedCode = encryptedCode + chr(c)
print("Encrypted text: ", +encryptedCode)
#project 2
fname= open("D:\Writing_code_Python\Learning_Python_in_book\VoVietThanh_58474_CH04\Projects\modifyproject1_2.txt",'r')
text = fname.read()
word = len(text.split())
text = input("Please enter any text: ")
d = int(input("Please enter the distance : "))
plainText = ""
for ch in text:
    ordvalue = ord(ch)
    ciphervalue = ordvalue - d
    if ciphervalue < ord('a'):
        ciphervalue = ord('z') - \
        (d - (ord('a')-ordvalue - 1))
        plainText += chr(ciphervalue)
print(plainText)

