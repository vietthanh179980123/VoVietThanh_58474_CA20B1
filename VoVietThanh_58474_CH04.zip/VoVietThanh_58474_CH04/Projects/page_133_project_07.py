"""
Author: Võ Viết Thanh
Date: 26/09/2021
Program: Write a script that decrypts a message coded by the method used in Project 6.
Solution:
  ....
"""
message = input("Enter here: ")
decimal = 0
exponent = len(message) - 1
bString = ""
for digit in message.split():
    decimal = decimal + int(digit) * 2 ** exponent
    exponent = exponent - 1
    bString += chr(int(digit, 2))
print(bString)


