"""
Author: Võ Viết Thanh
Date: 25/09/2021
Program: Write a script that inputs a line of plaintext and a distance value and outputs an
encrypted text using a Caesar cipher. The script should work for any printable
characters
Solution:
  ....
"""
text = input("Please enter any text: ")
d = int(input("Please enter the distance : "))
encryptedCode = ""
for character in text:
    oV = ord(character)
    c = oV + d
    if c > ord('z'):
        c = ord('a') + d - (ord('z') - oV + 1)
        encryptedCode = encryptedCode + chr(c)
print("Encrypted text: ", +encryptedCode)
