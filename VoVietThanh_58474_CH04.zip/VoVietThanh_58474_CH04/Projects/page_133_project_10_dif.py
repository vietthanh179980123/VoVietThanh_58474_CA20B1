"""
Author: Võ Viết Thanh
Date: 26/09/2021
Program: Write a script named dif.py. This script should prompt the user for the names
of two text files and compare the contents of the two files to see if they are the
same. If they are, the script should simply output "Yes". If they are not, the script
should output "No", followed by the first lines of each file that differ from each
other. The input loop should read and compare lines from each file. The loop
should break as soon as a pair of different lines is found.
Solution:
  ....
"""
f1 = open("project_10_f1.txt", 'r')
f2 = open("project_10_f2.txt", 'r')
text1 = f1.read()
text2= f2.read()
same = True
for line1 in f1:
    for line2 in f2:
        if line1 != line2:
            if f1==f2:
                same= False
                print("No")
                print(line1)
                print(line2)
                break
if same:
    print("Yes")

