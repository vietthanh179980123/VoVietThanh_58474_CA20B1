"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Consult the Table of ASCII values in Chapter 2 and suggest how you would modify
the encryption and decryption scripts in this section to work with strings containing all of the printable characters.
Solution:
 The main shortcoming of this encryption strategy is that the plaintext is encrypted one character at
a time, and each encrypted character depends on that single character and a fixed distance
value. In a sense, the structure of the original text is preserved in the cipher text, so it might
not be hard to discover a key by visual inspection.
  ....
"""
