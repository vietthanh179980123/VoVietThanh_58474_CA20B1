"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Write a code segment that prompts the user for a filename. If the file exists, the
program should print its contents on the terminal. Otherwise, it should print an
error message
Solution:
  ....
"""
# mở file testbai5.txt
fname = input("Enter file name: ")
fh = open(fname)
try:
    fh
except fh:
    print('Cannot open the file ',fname ,'please try again')
    quit()
for line in fh :
    line = line.upper()
    line = line.rstrip()
    print(line)
