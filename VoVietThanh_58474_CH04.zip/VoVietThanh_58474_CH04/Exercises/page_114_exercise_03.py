"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Translate each of the following numbers to binary numbers:
a. 478
b. 1278
c. 648
Solution:
    a.100111
    b.1010111
    c.110100
  ....
"""
