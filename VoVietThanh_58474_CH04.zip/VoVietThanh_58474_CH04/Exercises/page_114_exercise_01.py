"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Translate each of the following numbers to decimal numbers:
a. 110012
b. 1000002
c. 111112
Solution:
    a.25
    b.32
    c.31
  ....
"""


