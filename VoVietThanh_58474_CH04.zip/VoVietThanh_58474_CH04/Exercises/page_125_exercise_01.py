"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program:Write a code segment that opens a file named myfile.txt for input and prints the
number of lines in the file.
Solution:
  ....
"""
fname = "D:\Writing_code_Python\Learning_Python_in_book\VoVietThanh_58474_CH04\Exercises\myfile.txt"
count = 0
with open(fname, 'r') as f:
    for line in f:
        count += 1
print("Total number of lines is:", count)

