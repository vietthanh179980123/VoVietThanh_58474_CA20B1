"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Write a code segment that opens a file for input and prints the number of
four-letter words in the file
Solution:
  ....
"""
# mở file test bai2.txt
filename = input("Enter name of file: ")
file = open(filename, 'r')
file1 = open(filename, 'w')
i = 0
for element in file:
    words = element.split()
    for i in range(len(words)):
        if len(words[i]) == 4:
            file1 = element.replace(i, "xxxx")
            i = i+1
    file.close()
