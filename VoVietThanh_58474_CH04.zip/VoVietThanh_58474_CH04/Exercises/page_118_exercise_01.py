"""
Author: Võ Viết Thanh
Date: 24/09/2021
Program: Assume that the variable data refers to the string "Python rules!". Use a string
method from Table 4-2 to perform the following tasks:
a. Obtain a list of the words in the string.
b. Convert the string to uppercase.
c. Locate the position of the string "rules".
d. Replace the exclamation point with a question mark.
Solution:
    a. s.center(12)
    'Python rules!'
    b. s.upper()
    'PYTHON RULES!'
    c. s.find("rules")
    7
    d. s.replace('!', '?')
    'Python rules?'

  ....
"""
s= "Python rules"
s.center(12)
s.upper()
s.find("rules")
s.replace('!', '?')
